# -*- coding: utf-8 -*-
import secrets

import psycopg2
from psycopg2 import sql
from flask import Flask, flash, redirect, render_template, request, session, url_for

# =====================================================================
# [1] CONFIGURACIÓN  <-- [MODIFICABLE] datos del servidor PostgreSQL
# =====================================================================
DB_HOST = "192.168.122.185"   # IP de oradeb (si cambia, se cambia solo aquí)
DB_PORT = 5432                # puerto por defecto de PostgreSQL
DB_NAME = "prueba_bd"         # base de datos a la que se conecta la web
MAX_FILAS = 50                # máximo de filas que se muestran

app = Flask(__name__)
app.secret_key = secrets.token_hex(16)   # firma la cookie de sesión

# Aquí guardamos usuario y contraseña de quien ha entrado.
# En la cookie solo viaja un código aleatorio, nunca la contraseña.
SESIONES = {}


# =====================================================================
# [2] CONEXIÓN A POSTGRESQL  <-- [MODIFICABLE] cadena de conexión
# =====================================================================
def conectar(usuario, clave):
    # Equivalente en formato URI:
    # postgresql://usuario:clave@192.168.122.185:5432/prueba_bd
    conexion = psycopg2.connect(
        host=DB_HOST,
        port=DB_PORT,
        dbname=DB_NAME,
        user=usuario,
        password=clave,
        connect_timeout=5,
    )
    conexion.autocommit = True   # cada orden se guarda al ejecutarse
    return conexion


# =====================================================================
# [3] FUNCIONES AUXILIARES (seguras, no hace falta tocarlas)
# =====================================================================
def credenciales():
    """Devuelve usuario y contraseña de la sesión actual, o None."""
    return SESIONES.get(session.get("token"))


def tablas_accesibles(cur):
    """Tablas que el usuario conectado tiene permiso para leer (SELECT)."""
    cur.execute("""
        SELECT table_name
        FROM information_schema.tables
        WHERE table_schema = 'public'
          AND has_table_privilege(table_schema || '.' || table_name, 'SELECT')
        ORDER BY table_name
    """)
    return [fila[0] for fila in cur.fetchall()]


def columnas_de(cur, tabla):
    """Nombres de las columnas de una tabla."""
    cur.execute("""
        SELECT column_name
        FROM information_schema.columns
        WHERE table_schema = 'public' AND table_name = %s
        ORDER BY ordinal_position
    """, (tabla,))
    return [fila[0] for fila in cur.fetchall()]


def listar_registros(cur, tabla):
    """Primeras filas de la tabla, sin filtro."""
    cur.execute(sql.SQL("SELECT * FROM {} LIMIT %s").format(sql.Identifier(tabla)),
                (MAX_FILAS,))
    return [d[0] for d in cur.description], cur.fetchall()


# =====================================================================
# [4] BÚSQUEDA DE REGISTROS
#     [PARTE CORREGIDA] consulta parametrizada
# =====================================================================
def buscar_registros(cur, tabla, columna, valor):
    # SEGURO: la estructura de la consulta es fija. El valor viaja aparte (%s).
    consulta = sql.SQL("SELECT * FROM {tabla} WHERE CAST({columna} AS TEXT) = %s").format(
        tabla=sql.Identifier(tabla),
        columna=sql.Identifier(columna),
    )
    try:
        cur.execute(consulta, (valor,))
        encabezados = [d[0] for d in cur.description]
        filas = cur.fetchall()
        return encabezados, filas, None, None
    except psycopg2.Error:
        # SEGURO: mensaje genérico, sin revelar detalles internos
        return [], [], None, "No se ha podido realizar la búsqueda."

# =====================================================================
# [5] RUTAS (las páginas de la web)
# =====================================================================
@app.route("/")
def inicio():
    return redirect(url_for("tablas" if credenciales() else "login"))


@app.route("/login", methods=["GET", "POST"])
def login():
    if request.method == "POST":
        usuario = request.form["usuario"]
        clave = request.form["clave"]
        try:
            # La autenticación la hace PostgreSQL (contraseña + pg_hba.conf)
            conectar(usuario, clave).close()
        except psycopg2.Error:
            flash("No se pudo iniciar sesión: usuario, contraseña o acceso no válidos.")
            return render_template("login.html")
        token = secrets.token_hex(16)
        SESIONES[token] = {"usuario": usuario, "clave": clave}
        session["token"] = token
        return redirect(url_for("tablas"))
    return render_template("login.html")


@app.route("/logout")
def logout():
    SESIONES.pop(session.pop("token", None), None)
    return redirect(url_for("login"))


@app.route("/tablas")
def tablas():
    cred = credenciales()
    if not cred:
        return redirect(url_for("login"))
    conexion = conectar(cred["usuario"], cred["clave"])
    lista = tablas_accesibles(conexion.cursor())
    conexion.close()
    return render_template("tablas.html", usuario=cred["usuario"], tablas=lista)


@app.route("/tabla/<nombre>")
def ver_tabla(nombre):
    cred = credenciales()
    if not cred:
        return redirect(url_for("login"))

    conexion = conectar(cred["usuario"], cred["clave"])
    cur = conexion.cursor()

    # Solo dejamos entrar en tablas que el usuario puede leer
    if nombre not in tablas_accesibles(cur):
        conexion.close()
        flash("No tienes permiso para ver esa tabla.")
        return redirect(url_for("tablas"))

    columnas = columnas_de(cur, nombre)
    columna = request.args.get("columna", columnas[0])
    if columna not in columnas:          # la columna debe existir de verdad
        columna = columnas[0]
    valor = request.args.get("valor", "")

    consulta, error = None, None
    if valor:
        encabezados, filas, consulta, error = buscar_registros(cur, nombre, columna, valor)
    else:
        encabezados, filas = listar_registros(cur, nombre)
    conexion.close()

    return render_template("tabla.html", usuario=cred["usuario"], nombre=nombre,
                           columnas=columnas, columna=columna, valor=valor,
                           encabezados=encabezados, filas=filas,
                           consulta=consulta, error=error)


# =====================================================================
# [6] ARRANQUE
# =====================================================================
if __name__ == "__main__":
    # Solo escucha en nuestro propio equipo (127.0.0.1) porque la app es
    # vulnerable A PROPÓSITO y no debe verse desde la red.
    # No uses debug=True: abriría una consola de ejecución de código.
    app.run(host="127.0.0.1", port=5000, debug=False)
