from urllib.parse import quote_plus
from bson import json_util
from pymongo import MongoClient
from pymongo.errors import OperationFailure

# Campos que la aplicación nunca enseña en pantalla (en una proyección de MongoDB, 0 = ocultar)
camposOcultos = {'clave': 0}

# Máximo de documentos que se muestran en cada consulta
maximoDocumentosMostrados = 20

# Cuántos documentos se miran para averiguar qué campos tiene una colección
maximoDocumentosMuestra = 50


# ---------------------------------------------------------------
# CONEXIÓN CON MONGODB
# ---------------------------------------------------------------

def construirCadenaConexion(usuario, claveCodificada, host, puerto, nombreBaseDatos, authSource):
    # Formato: mongodb://usuario:clave@host:puerto/baseDatos?authSource=authSource
    credenciales = quote_plus(usuario) + ':' + claveCodificada
    direccionServidor = host + ':' + puerto
    opciones = '?authSource=' + authSource
    return 'mongodb://' + credenciales + '@' + direccionServidor + '/' + nombreBaseDatos + opciones


def conectarMongo(host, puerto, usuario, clave, nombreBaseDatos, authSource):
    if host == '' or usuario == '' or nombreBaseDatos == '':
        raise ValueError('Rellena el host, el usuario y la base de datos.')
    if authSource == '':
        authSource = nombreBaseDatos

    # quote_plus evita que símbolos como @ o : en la contraseña rompan la cadena
    claveCodificada = quote_plus(clave)

    cadena = construirCadenaConexion(usuario, claveCodificada, host, puerto, nombreBaseDatos, authSource)
    # La misma cadena, pero con la contraseña oculta, para poder enseñarla en pantalla
    cadenaOculta = construirCadenaConexion(usuario, '****', host, puerto, nombreBaseDatos, authSource)

    cliente = MongoClient(cadena, serverSelectionTimeoutMS=5000)
    # MongoClient no conecta hasta que se usa: esta orden fuerza la conexión y la autenticación
    cliente.admin.command('connectionStatus')
    return cliente, cadenaOculta


def obtenerRoles(cliente):
    estadoConexion = cliente.admin.command('connectionStatus')
    infoAutenticacion = estadoConexion.get('authInfo', {})
    return infoAutenticacion.get('authenticatedUserRoles', [])


def mensajeError(error):
    codigoError = getattr(error, 'code', None)
    if codigoError == 13:  # 13 = Unauthorized (sin permisos)
        return 'Permiso denegado: tu usuario de MongoDB no puede hacer esta operación.'
    # MEDIDA 6: mensaje genérico. El detalle real solo se escribe en la consola del servidor,
    # para no enseñar al usuario información interna de la base de datos.
    print('Error de MongoDB:', error)
    return 'No se pudo completar la operación en MongoDB.'


# ---------------------------------------------------------------
# COLECCIONES (solo las que el usuario tiene permiso para ver)
# ---------------------------------------------------------------

def contarDocumentos(coleccion):
    # Devuelve None si el usuario no tiene permiso para contar los documentos
    try:
        return coleccion.estimated_document_count()
    except OperationFailure:
        return None


def obtenerNombresColecciones(baseDatos):
    # authorizedCollections=True: MongoDB solo devuelve las colecciones donde el usuario tiene algún permiso
    try:
        return baseDatos.list_collection_names(authorizedCollections=True)
    except OperationFailure:
        # Servidores antiguos que no entienden esa opción
        return baseDatos.list_collection_names()


def obtenerColecciones(baseDatos):
    colecciones = []
    for nombre in sorted(obtenerNombresColecciones(baseDatos)):
        total = contarDocumentos(baseDatos[nombre])
        colecciones.append({'nombre': nombre, 'total': total})
    return colecciones


# ---------------------------------------------------------------
# DOCUMENTOS Y BÚSQUEDA
# ---------------------------------------------------------------

def obtenerCamposPermitidos(coleccion):
    # Campos que existen en la colección y que la aplicación enseña en pantalla
    campos = []
    muestra = coleccion.find({}, camposOcultos).limit(maximoDocumentosMuestra)
    for documento in muestra:
        for campo in documento:
            if campo not in campos:
                campos.append(campo)
    return campos


def construirFiltro(campo, valor):
    # MEDIDA 2: el valor nunca se convierte en un objeto, siempre es un dato suelto
    # (texto o número). Por eso {"$ne": ""} se busca como texto literal, no como operador.
    valorEsNumero = valor.replace('.', '', 1).isdigit()
    if valorEsNumero:
        return {'$or': [{campo: valor}, {campo: float(valor)}]}
    return {campo: valor}


def convertirDocumentosATexto(documentos):
    textos = []
    for documento in documentos:
        # json_util (y no json) porque el _id de MongoDB es un ObjectId, que json no sabe escribir
        textos.append(json_util.dumps(documento, indent=2, ensure_ascii=False))
    return textos


def buscarDocumentos(coleccion, campo, valor):
    hayBusqueda = campo != '' and valor != ''
    if hayBusqueda:
        # MEDIDA 1: el campo tiene que ser uno de los que existen y se muestran.
        # Esto bloquea nombres como "clave" (oculto) o "$where" (un operador).
        if campo not in obtenerCamposPermitidos(coleccion):
            raise ValueError('El campo "' + campo + '" no existe en esta colección.')
        filtro = construirFiltro(campo, valor)
    else:
        filtro = {}  # un filtro vacío significa "todos los documentos"

    documentos = coleccion.find(filtro, camposOcultos).limit(maximoDocumentosMostrados)
    return filtro, convertirDocumentosATexto(documentos)
