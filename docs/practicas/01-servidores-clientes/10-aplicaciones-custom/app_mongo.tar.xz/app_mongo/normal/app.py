from flask import Flask, render_template, request, redirect, flash
from pymongo.errors import PyMongoError, OperationFailure, ServerSelectionTimeoutError

from funciones import *

app = Flask(__name__)
app.secret_key = 'clave-de-ejemplo'

# Aquí se guarda la conexión del usuario que ha iniciado sesión.
# (esta app atiende a un usuario a la vez)
conexion = {'cliente': None, 'baseDatos': None, 'usuario': None, 'cadenaOculta': None}


def sinConexion():
    return conexion['cliente'] is None


def guardarConexion(cliente, nombreBaseDatos, usuario, cadenaOculta):
    conexion['cliente'] = cliente
    conexion['baseDatos'] = cliente[nombreBaseDatos]
    conexion['usuario'] = usuario
    conexion['cadenaOculta'] = cadenaOculta


def borrarConexion():
    if conexion['cliente'] is not None:
        conexion['cliente'].close()
    for dato in conexion:
        conexion[dato] = None


@app.route('/', methods=['GET', 'POST'])
def login():
    if request.method == 'POST':
        host = request.form.get('host', '').strip()
        puerto = request.form.get('puerto', '').strip()
        usuario = request.form.get('usuario', '').strip()
        clave = request.form.get('clave', '')
        nombreBaseDatos = request.form.get('nombreBaseDatos', '').strip()
        authSource = request.form.get('authSource', '').strip()

        try:
            cliente, cadenaOculta = conectarMongo(host, puerto, usuario, clave, nombreBaseDatos, authSource)
        except ValueError as error:
            flash(str(error), 'error')
        except ServerSelectionTimeoutError:
            flash('No se pudo conectar con el servidor. Revisa el host, el puerto y el firewall.', 'error')
        except OperationFailure:
            flash('Usuario, contraseña o base de datos de autenticación incorrectos.', 'error')
        else:
            # Solo se llega aquí si la conexión y la autenticación han ido bien
            guardarConexion(cliente, nombreBaseDatos, usuario, cadenaOculta)
            return redirect('/colecciones')

    return render_template('login.html', datosFormulario=request.form)


@app.route('/colecciones')
def colecciones():
    if sinConexion():
        return redirect('/')

    listaColecciones = []
    roles = []
    try:
        listaColecciones = obtenerColecciones(conexion['baseDatos'])
        roles = obtenerRoles(conexion['cliente'])
    except PyMongoError as error:
        flash(mensajeError(error), 'error')

    return render_template('colecciones.html', colecciones=listaColecciones, roles=roles,
                           usuario=conexion['usuario'], cadenaOculta=conexion['cadenaOculta'],
                           nombreBaseDatos=conexion['baseDatos'].name)


@app.route('/documentos/<nombreColeccion>')
def documentos(nombreColeccion):
    if sinConexion():
        return redirect('/')

    # Se prepara el acceso a la colección (todavía no se consulta nada a MongoDB)
    coleccion = conexion['baseDatos'][nombreColeccion]

    # Lo que el usuario ha escrito en el buscador. Llega en la dirección:
    # /documentos/usuarios?campo=usuario&valor=ana
    campo = request.args.get('campo', '').strip()
    valor = request.args.get('valor', '').strip()

    # Valores iniciales: así existen aunque la búsqueda falle y se salte al except
    filtro = {}
    listaDocumentos = []
    try:
        filtro, listaDocumentos = buscarDocumentos(coleccion, campo, valor)
    except PyMongoError as error:
        flash(mensajeError(error), 'error')
    except Exception as error:
        flash('Búsqueda no válida: ' + str(error), 'error')

    return render_template('documentos.html', nombreColeccion=nombreColeccion, documentos=listaDocumentos,
                           campo=campo, valor=valor, filtro=filtro)


@app.route('/salir')
def salir():
    borrarConexion()
    return redirect('/')


app.run('127.0.0.1', 5000, debug=True)
