import json
from urllib.parse import quote_plus
from bson import json_util
from pymongo import MongoClient
from pymongo.errors import OperationFailure

# Campos que la aplicación nunca enseña en pantalla (en una proyección de MongoDB, 0 = ocultar)
camposOcultos = {'clave': 0}

# Máximo de documentos que se muestran en cada consulta
maximoDocumentosMostrados = 20


# ---------------------------------------------------------------
# CONEXIÓN CON MONGODB
# ---------------------------------------------------------------

def construirCadenaConexion(usuario, claveCodificada, host, puerto, nombreBaseDatos, authSource):
    # Formato: mongodb://usuario:clave@host:puerto/baseDatos?authSource=authSource
    credenciales = quote_plus(usuario) + ':' + claveCodificada
    direccionServidor = host + ':' + puerto
    opciones = '?authSource=' + authSource
    return 'mongodb://' + credenciales + '@' + direccionServidor + '/' + nombreBaseDatos + opciones


def conectarMongo(host, puerto, usuario, clave, nombreBaseDatos, authSource):
    if host == '' or usuario == '' or nombreBaseDatos == '':
        raise ValueError('Rellena el host, el usuario y la base de datos.')
    if authSource == '':
        authSource = nombreBaseDatos

    # quote_plus evita que símbolos como @ o : en la contraseña rompan la cadena
    claveCodificada = quote_plus(clave)

    cadena = construirCadenaConexion(usuario, claveCodificada, host, puerto, nombreBaseDatos, authSource)
    # La misma cadena, pero con la contraseña oculta, para poder enseñarla en pantalla
    cadenaOculta = construirCadenaConexion(usuario, '****', host, puerto, nombreBaseDatos, authSource)

    cliente = MongoClient(cadena, serverSelectionTimeoutMS=5000)
    # MongoClient no conecta hasta que se usa: esta orden fuerza la conexión y la autenticación
    cliente.admin.command('connectionStatus')
    return cliente, cadenaOculta


def obtenerRoles(cliente):
    estadoConexion = cliente.admin.command('connectionStatus')
    infoAutenticacion = estadoConexion.get('authInfo', {})
    return infoAutenticacion.get('authenticatedUserRoles', [])


def mensajeError(error):
    codigoError = getattr(error, 'code', None)
    if codigoError == 13:  # 13 = Unauthorized (sin permisos)
        return 'Permiso denegado: tu usuario de MongoDB no puede hacer esta operación.'
    return 'MongoDB: ' + str(error)


# ---------------------------------------------------------------
# COLECCIONES (solo las que el usuario tiene permiso para ver)
# ---------------------------------------------------------------

def contarDocumentos(coleccion):
    # Devuelve None si el usuario no tiene permiso para contar los documentos
    try:
        return coleccion.estimated_document_count()
    except OperationFailure:
        return None


def obtenerNombresColecciones(baseDatos):
    # authorizedCollections=True: MongoDB solo devuelve las colecciones donde el usuario tiene algún permiso
    try:
        return baseDatos.list_collection_names(authorizedCollections=True)
    except OperationFailure:
        # Servidores antiguos que no entienden esa opción
        return baseDatos.list_collection_names()


def obtenerColecciones(baseDatos):
    colecciones = []
    for nombre in sorted(obtenerNombresColecciones(baseDatos)):
        total = contarDocumentos(baseDatos[nombre])
        colecciones.append({'nombre': nombre, 'total': total})
    return colecciones


# ---------------------------------------------------------------
# DOCUMENTOS Y BÚSQUEDA
# ---------------------------------------------------------------

def construirFiltro(campo, valor):
    # Para permitir búsquedas más avanzadas, si el valor empieza por { se
    # interpreta como un filtro de MongoDB, por ejemplo {"$gt": 1000}
    if valor.startswith('{'):
        valor = json.loads(valor)
    return {campo: valor}


def convertirDocumentosATexto(documentos):
    textos = []
    for documento in documentos:
        # json_util (y no json) porque el _id de MongoDB es un ObjectId, que json no sabe escribir
        textos.append(json_util.dumps(documento, indent=2, ensure_ascii=False))
    return textos


def buscarDocumentos(coleccion, campo, valor):
    hayBusqueda = campo != '' and valor != ''
    if hayBusqueda:
        filtro = construirFiltro(campo, valor)
    else:
        filtro = {}  # un filtro vacío significa "todos los documentos"

    documentos = coleccion.find(filtro, camposOcultos).limit(maximoDocumentosMostrados)
    return filtro, convertirDocumentosATexto(documentos)
