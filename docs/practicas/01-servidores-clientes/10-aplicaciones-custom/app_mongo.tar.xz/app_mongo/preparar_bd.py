# Crea los datos de prueba y los usuarios de MongoDB para probar la aplicación.
# Sirve para las dos versiones (normal y segura), ya que usan la misma base de datos.
# Ejecutar una sola vez:  python preparar_bd.py
from getpass import getpass
from pymongo import MongoClient
from pymongo.errors import OperationFailure

host = input('Host [localhost]: ') or 'localhost'
puerto = int(input('Puerto [27017]: ') or 27017)
admin = input('Usuario administrador (déjalo vacío si el servidor no tiene autenticación): ')

if admin != '':
    claveAdmin = getpass('Contraseña del administrador: ')
    cliente = MongoClient(host, puerto, username=admin, password=claveAdmin, authSource='admin')
else:
    cliente = MongoClient(host, puerto)

baseDatos = cliente['toyota']

# ---------- Datos ----------
baseDatos['Concesionarios'].drop()
baseDatos['Concesionarios'].insert_many([
    {'code': '99910', 'name': 'Toyota Central', 'city': 'Sevilla', 'state': 'ES', 'rating': 4.7},
    {'code': '99911', 'name': 'Toyota Norte', 'city': 'Madrid', 'state': 'ES', 'rating': 4.2},
    {'code': '99912', 'name': 'Toyota Levante', 'city': 'Valencia', 'state': 'ES', 'rating': 3.9},
])

# Las contraseñas se guardan en texto plano A PROPÓSITO, para poder demostrar el
# ataque NoSQL Injection. En una aplicación real deben guardarse siempre con hash.
baseDatos['usuarios'].drop()
baseDatos['usuarios'].insert_many([
    {'usuario': 'admin', 'clave': 'Secreto123', 'rol': 'administrador'},
    {'usuario': 'ana', 'clave': 'abc123', 'rol': 'empleado'},
    {'usuario': 'luis', 'clave': 'luis2026', 'rol': 'empleado'},
])
print('Datos creados en la base de datos "toyota".')


# ---------- Usuarios de MongoDB con distintos permisos ----------
def borrarSiExiste(comando, nombre):
    try:
        baseDatos.command(comando, nombre)
    except OperationFailure:
        pass  # No existía, no hay nada que borrar


# Rol personalizado: solo puede leer la colección Concesionarios
borrarSiExiste('dropRole', 'soloConcesionarios')
baseDatos.command('createRole', 'soloConcesionarios', roles=[], privileges=[
    {'resource': {'db': 'toyota', 'collection': 'Concesionarios'}, 'actions': ['find']}
])

usuarios = [
    ('lector', 'lector123', [{'role': 'read', 'db': 'toyota'}]),
    ('editor', 'editor123', [{'role': 'readWrite', 'db': 'toyota'}]),
    ('limitado', 'limitado123', [{'role': 'soloConcesionarios', 'db': 'toyota'}]),
]
for nombre, clave, roles in usuarios:
    borrarSiExiste('dropUser', nombre)
    baseDatos.command('createUser', nombre, pwd=clave, roles=roles)
    print('Usuario creado:', nombre, '/', clave)

print('Listo. Entra en la app con base de datos "toyota".')
